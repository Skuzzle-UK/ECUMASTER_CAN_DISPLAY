enum SCREENS{
  BEGIN,
  CLOCK,
  RPM,
  MAP,
  //BARO,
  CLT,
  AIT,
  //OILP,
  AFR,
  FUELTYPE,
  SPEED,
  END
};

enum DIRECTION{
  UP,
  DOWN
};